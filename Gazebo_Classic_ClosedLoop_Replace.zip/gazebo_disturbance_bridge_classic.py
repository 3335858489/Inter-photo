#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Gazebo Classic disturbance bridge for the AI-DT closed-loop experiment.

ROS 2 input:
    /ai_dt/disturbance_enable   std_msgs/Bool

ROS 2 output:
    /ai_dt/disturbance_status   std_msgs/Bool

Gazebo Classic services used:
    /gazebo/apply_body_wrench or /apply_body_wrench
    /gazebo/clear_body_wrenches or /clear_body_wrenches

Default target:
    dummy-ros2::link6_1_1

Default disturbance:
    Fz = -4.905 N
which is the gravity-equivalent force of 0.5 kg.

Run:
    python3 gazebo_disturbance_bridge_classic.py --ros-args \
      -p body_name:=dummy-ros2::link6_1_1 \
      -p force_z:=-4.905
"""

import rclpy
from rclpy.node import Node
from std_msgs.msg import Bool
from gazebo_msgs.srv import ApplyBodyWrench, ClearBodyWrenches


class GazeboClassicDisturbanceBridge(Node):
    def __init__(self):
        super().__init__('ai_dt_gazebo_classic_disturbance_bridge')

        self.declare_parameter('body_name', 'dummy-ros2::link6_1_1')
        self.declare_parameter('reference_frame', 'world')
        self.declare_parameter('force_x', 0.0)
        self.declare_parameter('force_y', 0.0)
        self.declare_parameter('force_z', -4.905)
        self.declare_parameter('torque_x', 0.0)
        self.declare_parameter('torque_y', 0.0)
        self.declare_parameter('torque_z', 0.0)
        self.declare_parameter('duration_sec', 3600)

        self.body_name = self.get_parameter('body_name').value
        self.reference_frame = self.get_parameter('reference_frame').value
        self.fx = float(self.get_parameter('force_x').value)
        self.fy = float(self.get_parameter('force_y').value)
        self.fz = float(self.get_parameter('force_z').value)
        self.tx = float(self.get_parameter('torque_x').value)
        self.ty = float(self.get_parameter('torque_y').value)
        self.tz = float(self.get_parameter('torque_z').value)
        self.duration_sec = int(self.get_parameter('duration_sec').value)

        self.apply_service = self._find_service(
            ['/gazebo/apply_body_wrench', '/apply_body_wrench'],
            'gazebo_msgs/srv/ApplyBodyWrench')
        self.clear_service = self._find_service(
            ['/gazebo/clear_body_wrenches', '/clear_body_wrenches'],
            'gazebo_msgs/srv/ClearBodyWrenches')

        if not self.apply_service:
            raise RuntimeError(
                'ApplyBodyWrench service not found. Run: ros2 service list | grep wrench')
        if not self.clear_service:
            raise RuntimeError(
                'ClearBodyWrenches service not found. Run: ros2 service list | grep wrench')

        self.apply_client = self.create_client(ApplyBodyWrench, self.apply_service)
        self.clear_client = self.create_client(ClearBodyWrenches, self.clear_service)

        self.status_pub = self.create_publisher(Bool, '/ai_dt/disturbance_status', 10)
        self.sub = self.create_subscription(
            Bool, '/ai_dt/disturbance_enable', self._on_enable, 10)

        self.enabled = False
        self._publish_status(False)

        self.get_logger().info(
            f'Ready. body={self.body_name}, F=({self.fx}, {self.fy}, {self.fz}) N')
        self.get_logger().info(
            f'Apply service: {self.apply_service}; Clear service: {self.clear_service}')

    def _find_service(self, candidates, expected_type):
        # Give graph discovery a short moment.
        rclpy.spin_once(self, timeout_sec=0.5)
        services = dict(self.get_service_names_and_types())
        for name in candidates:
            types = services.get(name, [])
            if expected_type in types or name in services:
                return name
        return None

    def _publish_status(self, state):
        msg = Bool()
        msg.data = bool(state)
        self.status_pub.publish(msg)

    def _on_enable(self, msg):
        requested = bool(msg.data)
        if requested == self.enabled:
            self._publish_status(self.enabled)
            return

        if requested:
            self._apply()
        else:
            self._clear()

    def _apply(self):
        req = ApplyBodyWrench.Request()
        req.body_name = self.body_name
        req.reference_frame = self.reference_frame

        req.reference_point.x = 0.0
        req.reference_point.y = 0.0
        req.reference_point.z = 0.0

        req.wrench.force.x = self.fx
        req.wrench.force.y = self.fy
        req.wrench.force.z = self.fz
        req.wrench.torque.x = self.tx
        req.wrench.torque.y = self.ty
        req.wrench.torque.z = self.tz

        req.start_time.sec = 0
        req.start_time.nanosec = 0
        req.duration.sec = self.duration_sec
        req.duration.nanosec = 0

        future = self.apply_client.call_async(req)
        future.add_done_callback(self._apply_done)

    def _apply_done(self, future):
        try:
            resp = future.result()
            if resp.success:
                self.enabled = True
                self.get_logger().info(
                    f'Disturbance ENABLED on {self.body_name}: Fz={self.fz:.4f} N')
            else:
                self.enabled = False
                self.get_logger().error(
                    f'Apply wrench rejected: {resp.status_message}')
        except Exception as exc:
            self.enabled = False
            self.get_logger().error(f'Apply wrench failed: {exc}')
        self._publish_status(self.enabled)

    def _clear(self):
        req = ClearBodyWrenches.Request()
        req.body_name = self.body_name
        future = self.clear_client.call_async(req)
        future.add_done_callback(self._clear_done)

    def _clear_done(self, future):
        try:
            resp = future.result()
            if resp.success:
                self.enabled = False
                self.get_logger().info(
                    f'Disturbance DISABLED on {self.body_name}')
            else:
                self.get_logger().error(
                    f'Clear wrench rejected: {resp.status_message}')
        except Exception as exc:
            self.get_logger().error(f'Clear wrench failed: {exc}')
        self._publish_status(self.enabled)


def main(args=None):
    rclpy.init(args=args)
    node = None
    try:
        node = GazeboClassicDisturbanceBridge()
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    except Exception as exc:
        print(f'[gazebo_disturbance_bridge_classic] ERROR: {exc}')
    finally:
        if node is not None:
            node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
