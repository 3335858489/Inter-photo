#!/usr/bin/env bash
set -u

export ROS_DOMAIN_ID="${ROS_DOMAIN_ID:-0}"

echo "============================================================"
echo "AI-DT Gazebo Classic feedback precheck"
echo "ROS_DOMAIN_ID=${ROS_DOMAIN_ID}"
echo "============================================================"

echo
echo "[1/5] Controllers"
ros2 control list_controllers

echo
echo "[2/5] Hardware interfaces"
ros2 control list_hardware_interfaces

echo
echo "[3/5] /joint_states one sample"
ros2 topic echo /joint_states --once

echo
echo "[4/5] FollowJointTrajectory actions"
ros2 action list | grep follow_joint_trajectory || true

echo
echo "[5/5] Gazebo wrench services"
ros2 service list | grep -E 'apply_body_wrench|clear_body_wrenches|wrench' || true

echo
echo "Expected after replacing dummy-ros2.xacro:"
echo "  Joint1/effort ... Joint6/effort appear under state interfaces"
echo "  /joint_states effort contains finite numbers, not .nan"
echo "============================================================"
