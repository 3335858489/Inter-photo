function xyz = forward_kinematics_sim_batch(Q)
% FORWARD_KINEMATICS_SIM_BATCH 批量六轴正运动学
%
% 输入:
%   Q - N×6 关节角矩阵（单位：度 °）
%       每一行：[q1 q2 q3 q4 q5 q6]
%
% 输出:
%   xyz - N×3 末端位置轨迹 [X Y Z]
%
% 示例:
%   xyz = forward_kinematics_sim_batch(pos_ref1);

    % ---------- 机械臂参数 ----------
    p = [-0.019225  -0.000523   0.100684;
         -0.0155     0.035      0.0285;
          0.03665    0          0.146;
         -0.01855   -0.01       0.052;
          0.0168     0.127      0;
         -0.018506   0.077     -0.000106];

    ax = [ 0  0 -1;
          -1  0  0;
          -1  0  0;
           0 -1  0;
          -1  0  0;
           0 -1  0];

    N = size(Q, 1);
    xyz = zeros(N, 3);

    % ---------- 对每个时间点计算 ----------
    for k = 1:N
        q = Q(k, :)';          % 6×1
        T = eye(4);

        for i = 1:6
            % 平移
            Tt = eye(4);
            Tt(1:3,4) = p(i,:)';

            % 旋转轴
            u = ax(i,:)/norm(ax(i,:));
            ux = u(1); uy = u(2); uz = u(3);

            % 转角（度 → 弧度）
            th = deg2rad(q(i));
            c = cos(th); s = sin(th); v = 1 - c;

            % 罗德里格斯公式
            R = [ ux^2*v + c,      ux*uy*v - uz*s,  ux*uz*v + uy*s;
                  ux*uy*v + uz*s,  uy^2*v + c,      uy*uz*v - ux*s;
                  ux*uz*v - uy*s,  uy*uz*v + ux*s,  uz^2*v + c ];

            Tr = eye(4);
            Tr(1:3,1:3) = R;

            T = T * (Tt * Tr);
        end

        xyz(k,:) = T(1:3,4)';
    end
end






