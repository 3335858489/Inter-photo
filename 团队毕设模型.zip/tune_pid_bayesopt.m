function [opt_params, min_cost, results] = tune_pid_bayesopt(model_name, t_sim, max_evals)
% TUNE_PID_BAYESOPT 使用贝叶斯优化整定 Simulink 模型的 PID 及前馈/速度(kv)参数
%
% 调用格式:
%   [opt_params, min_cost, results] = tune_pid_bayesopt()
%   [opt_params, min_cost, results] = tune_pid_bayesopt('DT_test', 1, 10)
%
% 输入参数:
%   model_name - Simulink 模型名称 (字符串，默认 'DT_test')
%   t_sim      - 仿真时间 (数值，默认 1 秒)
%   max_evals  - 最大目标函数评估次数 (数值，默认 10 次)
%
% 输出参数:
%   opt_params - 包含最优参数 kp, ki, kd, kv 的结构体
%   min_cost   - 最小代价函数值
%   results    - 贝叶斯优化的完整结果对象 (BayesianOptimization)

    %% 1. 处理输入参数默认值
    if nargin < 1 || isempty(model_name)
        model_name = 'DT_test';
    end
    if nargin < 2 || isempty(t_sim)
        t_sim = 1;
    end
    if nargin < 3 || isempty(max_evals)
        max_evals = 10;
    end

    %% 2. 定义基础参数与优化范围
    % PID 参数范围 (可根据实际物理限制在此处调整)
    kp_var = optimizableVariable('kp', [0, 500]);
    ki_var = optimizableVariable('ki', [0, 100]);
    kd_var = optimizableVariable('kd', [0, 500]);
    kv_var = optimizableVariable('kv', [0, 100]);
    

    

    objective = @(params) cost_function(params, model_name, t_sim);
    
    %% 4. 执行贝叶斯优化
    fprintf('开始对模型 "%s" 进行贝叶斯参数优化...\n', model_name);
    results = bayesopt(objective, [kp_var, ki_var, kd_var, kv_var], ...
        'MaxObjectiveEvaluations', max_evals, ...
        'NumSeedPoints', 5, ...
        'AcquisitionFunctionName', 'expected-improvement-plus', ...
        'Verbose', 1, ...
        'PlotFcn', {@plotMinObjective});
    
    %% 5. 提取并输出结果
    opt_params.kp = results.XAtMinObjective.kp;
    opt_params.ki = results.XAtMinObjective.ki;
    opt_params.kd = results.XAtMinObjective.kd;
    opt_params.kv = results.XAtMinObjective.kv;
    
    min_cost = results.MinObjective;
    
    fprintf('\n============================\n');
    fprintf('优化完成！最优参数结果:\n');
    fprintf('kp = %.6f\n', opt_params.kp);
    fprintf('ki = %.6f\n', opt_params.ki);
    fprintf('kd = %.6f\n', opt_params.kd);
    fprintf('kv = %.6f\n', opt_params.kv);
    fprintf('最优代价 = %.6f\n', min_cost);
    fprintf('============================\n');

end