% 如果 CSV 文件和函数在同一目录下，直接调用并赋值给基础工作区的变量
clc;clear;
[pos_ref1, vel_ref1] = generate_simulink_refs('Robot_Trajectory_pos_ref.xlsx');
 %% 基础参数设置
 model_name = 'DT_test';
 
 % PID参数范围
 kp_var = optimizableVariable('kp', [0, 500]);
 ki_var = optimizableVariable('ki', [0, 100]);
 kd_var = optimizableVariable('kd', [0, 500]);
 kv_var = optimizableVariable('kv', [0, 100]);
 
 % 仿真参数
 t_sim = 1;           % 仿真时间
 
 % 性能权重 [超调量, 调节时间, 上升时间, ITAE]
 weights = [0.44, 0.22, 0.22, 0.11];
 
 %% 定义目标函数
 objective = @(params) cost_function(params, model_name, t_sim);
 
 %% 执行贝叶斯优化
 results = bayesopt(objective, [kp_var, ki_var, kd_var,kv_var], ...
     'MaxObjectiveEvaluations', 10, ...
     'NumSeedPoints', 5, ...
     'AcquisitionFunctionName', 'expected-improvement-plus', ...
     'Verbose', 1, ...
     'PlotFcn', {@plotMinObjective});
 
 %% 输出结果
 kp_opt = results.XAtMinObjective.kp;
 ki_opt = results.XAtMinObjective.ki;
 kd_opt = results.XAtMinObjective.kd;
 kv_opt = results.XAtMinObjective.kv;
 
 
 fprintf('\n最优PID参数:\n');
 fprintf('kp = %.6f\n', kp_opt);
 fprintf('ki = %.6f\n', ki_opt);
 fprintf('kd = %.6f\n', kd_opt);
 fprintf('kv = %.6f\n', kv_opt);
 fprintf('最优代价 = %.6f\n', results.MinObjective);
 
