function j = cost_function(params, model_name,  t_sim)
     % 设置参数
     assignin('base', 'kp', params.kp);
     assignin('base', 'ki', params.ki);
     assignin('base', 'kd', params.kd);
     assignin('base', 'kv', params.kv);
     % 运行仿真
     try
         simOut = sim(model_name, 'StopTime', num2str(t_sim));
         err = simOut.err;
         time = simOut.tout;

         if isa(simOut.err, 'timeseries')
            err_data = simOut.err.Data;
            time = simOut.err.Time; % 推荐直接用该信号自己的时间戳
         else
             err_data = simOut.err;
             time = simOut.tout;
         end

% 2. 强制展平为列向量，保证维度绝对一致
         err_data = err_data(:);
         time = time(:);
 
    
  
         % ITAE计算
         error = abs(err_data);
         itae = trapz(time, time .* error);
 
         % 加权代价函数
         j = itae;%weights(1)*overshoot + weights(2)*settling_time + ...
             %weights(3)*rise_time + weights(4)*itae;
 
     catch
         fprintf('Error in cost_function\n');
         j = 1e6;  % 仿真失败惩罚，如果发现代价值一直是1000000，就说明有问题
     end
 end

