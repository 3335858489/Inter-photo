function [pos_ref1, vel_ref1, pos_ref2, vel_ref2, pos_ref3, vel_ref3, ...
 pos_ref4, vel_ref4, pos_ref5, vel_ref5, pos_ref6, vel_ref6] = ...
    generate_simulink_refs(filename)
% GENERATE_SIMULINK_REFS 读取Excel中6列位置参考，生成对应速度参考（timeseries对象）
%
% 输入参数:
%   filename - Excel文件名（如'Robot_Tr.xlsx'）
%
% 输出参数:
%   pos_ref1~pos_ref6 - 6轴位置参考（timeseries对象）
%   vel_ref1~vel_ref6 - 6轴速度参考（timeseries对象，由位置数值求导得到）

    %% 1. 检查文件是否存在
    if ~exist(filename, 'file')
        error('文件 "%s" 不存在！请确认路径和文件名正确。', filename);
    end

    %% 2. 读取Excel数据（兼容.xlsx和.csv）
    [~, ~, ext] = fileparts(filename); % 获取文件扩展名
    try
        if strcmpi(ext, '.xlsx')
            data = readtable(filename); % 读取Excel
        else
            opts = detectImportOptions(filename);
            data = readtable(filename, opts); % 读取CSV
        end
    catch ME
        error('读取文件失败：%s', ME.message);
    end

    %% 3. 校验表头（必须包含Time和pos_ref1~pos_ref6）
    required_vars = {'Time', 'pos_ref1', 'pos_ref2', 'pos_ref3', ...
                     'pos_ref4', 'pos_ref5', 'pos_ref6'};
    for var = required_vars
        if ~ismember(var{1}, data.Properties.VariableNames)
            error('Excel中缺少表头 "%s"，请检查列名！', var{1});
        end
    end

    %% 4. 提取时间列
    t = data.Time;

    %% 5. 逐列处理位置→速度（梯度求导，保证边界平滑）
    % 位置列名列表
    pos_vars = {'pos_ref1', 'pos_ref2', 'pos_ref3', 'pos_ref4', 'pos_ref5', 'pos_ref6'};
    % 预分配输出（元胞数组临时存储）
    pos_list = cell(1,6);
    vel_list = cell(1,6);

    for i = 1:6
        col_name = pos_vars{i};      % 当前位置列名（如'pos_ref1'）
        p = data.(col_name);         % 提取位置数据
        v = gradient(p, t);          % 数值求导（速度=位置对时间的导数）
        % 封装为timeseries对象（Simulink支持的格式）
        pos_list{i} = timeseries(p, t, 'Name', col_name);
        vel_list{i} = timeseries(v, t, 'Name', ['vel_' col_name(5:end)]); % 速度名：vel_ref1~vel_ref6
    end

    %% 6. 解包输出（按轴顺序返回）
    pos_ref1 = pos_list{1}; vel_ref1 = vel_list{1};
    pos_ref2 = pos_list{2}; vel_ref2 = vel_list{2};
    pos_ref3 = pos_list{3}; vel_ref3 = vel_list{3};
    pos_ref4 = pos_list{4}; vel_ref4 = vel_list{4};
    pos_ref5 = pos_list{5}; vel_ref5 = vel_list{5};
    pos_ref6 = pos_list{6}; vel_ref6 = vel_list{6};

    fprintf('轨迹处理完成：已生成6轴位置/速度参考（timeseries格式）。\n');
end