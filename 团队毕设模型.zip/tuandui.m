% =========================================================================
% 6 轴系统动态优化脚本 (0-3s 运行 -> 3s 冻结寻优 -> 3s-5s 优化续跑)
% 模型说明: 
%   1. 'DCE_motor6': 6电机模型，J1参数(Kp1,Kv1,Ki1,Kd1)，负载观测输出(TL)。
%   2. 'DT_test': 单电机数字孪生模型，仅用于 3s 时刻对 J1 进行贝叶斯寻优。
% =========================================================================
clear; clc; clearvars -global;

%% 1. 环境初始化与参考轨迹加载
disp('🌟 正在初始化 6 轴协同仿真环境...');
[pos_ref1, vel_ref1, pos_ref2, vel_ref2, pos_ref3, vel_ref3, ...
 pos_ref4, vel_ref4, pos_ref5, vel_ref5, pos_ref6, vel_ref6] = ...
    generate_simulink_refs('Robot_Tr.xlsx');

% 推送参考轨迹到工作区，供 DCE_motor6 模型读取
assignin('base', 'pos_ref1', pos_ref1); assignin('base', 'vel_ref1', vel_ref1);
assignin('base', 'pos_ref2', pos_ref2); assignin('base', 'vel_ref2', vel_ref2);
assignin('base', 'pos_ref3', pos_ref3); assignin('base', 'vel_ref3', vel_ref3);
assignin('base', 'pos_ref4', pos_ref4); assignin('base', 'vel_ref4', vel_ref4);
assignin('base', 'pos_ref5', pos_ref5); assignin('base', 'vel_ref5', vel_ref5);
assignin('base', 'pos_ref6', pos_ref6); assignin('base', 'vel_ref6', vel_ref6);

%% 2. 【核心步骤】：计算"理论理想 XYZ"并打包格式
% 提取 6 个关节的角度序列 (N x 6)
Q_ref = [squeeze(pos_ref1.Data), squeeze(pos_ref2.Data), squeeze(pos_ref3.Data), ...
         squeeze(pos_ref4.Data), squeeze(pos_ref5.Data), squeeze(pos_ref6.Data)];
% 单位转换：弧度转角度（forward_kinematics_sim_batch 函数要求单位为度）
Q_ref_deg = Q_ref * (180/pi);

% 通过代码计算出理想的 XYZ 轨迹序列 (N x 3)
xyz_ideal_raw = forward_kinematics_sim_batch(Q_ref_deg);

% --- 关键：将数据打包成 From Workspace 要求的格式 [Time, X, Y, Z] ---
% 第一列必须是时间轴，Simulink 靠这个来对齐信号
t_axis = pos_ref1.Time; 
xyz_ideal_signal = [t_axis, xyz_ideal_raw];

% 将打包好的信号变量存入工作区，变量名为 'xyz_ref'
assignin('base', 'xyz_ref', xyz_ideal_signal); 
disp('✅ 理想 XYZ 信号已打包并存入工作区 (变量名: xyz_ref)');







%% 1. 初始化变量
% --- 物理模型初始参数 (前1秒较弱的参数) ---
kp_P = 100;
kv_P = 80;
ki_P = 200;
kd_P = 250;

% --- 孪生调度时间设置 ---
t_phase1 = 3; % 第一阶段跑3秒
t_phase2 = 5.0; % 第二阶段跑到 5 秒

%% 2. 第一阶段：物理模型初始运行 (0s -> 1s)
fprintf('=== 🚀 阶段一：物理系统初始运行 (0 ~ %.1fs) ===\n', t_phase1);
% 创建物理模型的仿真输入对象
in_P1 = Simulink.SimulationInput('DCE_motor6');
in_P1 = in_P1.setVariable('kp_P', kp_P);
in_P1 = in_P1.setVariable('kv_P', kv_P);
in_P1 = in_P1.setVariable('ki_P', ki_P);
in_P1 = in_P1.setVariable('kd_P', kd_P);

% 核心魔法：配置保存 1s 时刻的底层工作点 (Operating Point)
in_P1 = in_P1.setModelParameter('SaveFinalState', 'on');
in_P1 = in_P1.setModelParameter('FinalStateName', 'P_FinalState_1s');
in_P1 = in_P1.setModelParameter('SaveOperatingPoint', 'on'); 

% 设置仿真时间
in_P1 = in_P1.setModelParameter('StartTime', '0');
in_P1 = in_P1.setModelParameter('StopTime', num2str(t_phase1));

% 执行仿真
out_P1 = sim(in_P1);
disp('✅ 阶段一运行结束！');

%% 3. 数据提取：观测 TL 并保存物理状态
fprintf('\n=== 🔍 阶段二：提取物理状态与观测负载 ===\n');
% 提取物理模型 1s 瞬间的"时间冻结快照"
saved_state = out_P1.P_FinalState_1s; 

% 提取观测到的真实负载 (获取数组的最后一个值)
if isprop(out_P1, 'TL_realtime')
    if isa(out_P1.TL_realtime, 'timeseries')
        current_TL = out_P1.TL_realtime.Data(end);
    else
        current_TL = out_P1.TL_realtime(end);
    end
else
    error('❌ 找不到 TL_realtime 变量！请检查 P_only 中的 To Workspace 模块。');
end
fprintf('💡 在 t=%.1fs 瞬间，物理观测器侦测到的真实负载为: %.4f N.m\n', t_phase1, current_TL);

%% 4. 第二阶段：数字模型寻优 (真实贝叶斯优化)
fprintf('\n=== 🧠 阶段三：调用数字孪生模型进行"真实贝叶斯寻优" ===\n');

% 将物理世界真实观测到的负载，推送到基础工作区
assignin('base', 'DT_Load', current_TL); 

disp('⏳ 数字孪生正在平行宇宙中疯狂运算 (启动贝叶斯优化)...');

% 调用贝叶斯优化 (1s评估时长，15次迭代)
[opt_params, min_cost, ~] = tune_pid_bayesopt('DT_test', 1, 15);

disp('✅ 数字孪生贝叶斯优化结束！');

% 提取真实寻优出来的最强参数
best_kp_P = opt_params.kp;  
best_ki_P = opt_params.ki;  
best_kv_P = opt_params.kv;
best_kd_P = opt_params.kd;

fprintf('🎯 寻优成功！即将向物理系统下发最优参数:\nKp=%.2f, Ki=%.2f, Kd=%.2f, Kv=%.2f\n(最小代价: %.4f)\n', ...
    best_kp_P, best_ki_P, best_kd_P, best_kv_P, min_cost);

%% 5. 第三阶段：物理模型断点续跑 (1s -> 2s)
fprintf('\n=== ⚡ 阶段四：物理系统注入新参数并断点续跑 (%.1fs ~ %.1fs) ===\n', t_phase1, t_phase2);
in_P2 = Simulink.SimulationInput('DCE_motor6');

% 1. 下发新参数
in_P2 = in_P2.setVariable('kp_P', best_kp_P);
in_P2 = in_P2.setVariable('kv_P', best_kv_P);
in_P2 = in_P2.setVariable('ki_P', best_ki_P);
in_P2 = in_P2.setVariable('kd_P', best_kd_P);

% 2. 注入历史记忆：加载 1s 时的底层工作点快照
in_P2 = in_P2.setInitialState(saved_state);

% 3. 时间顺延：从 1s 开始，跑到 2s
in_P2 = in_P2.setModelParameter('StartTime', num2str(t_phase1));
in_P2 = in_P2.setModelParameter('StopTime', num2str(t_phase2));

% 执行续跑仿真
out_P2 = sim(in_P2);
disp('✅ 阶段四续跑结束！');
fprintf('\n🎉 全流程数字孪生闭环验证完美成功！\n');

%% 6. 数据无缝缝合与全局可视化 (多子图进阶版)
disp('📊 正在缝合全局数据并生成专业级图表...');

% 1. 提取时间轴
t_phase1 = out_P1.tout;
t_phase2 = out_P2.tout;
t_total = [t_phase1; t_phase2];

% 2. 提取 Theta 数据并拼接
theta_phase1 = out_P1.Theta_data;
theta_phase2 = out_P2.Theta_data;
theta_total = [theta_phase1; theta_phase2];

% 3. 提取 Theta_error 数据并拼接 (兼容 Timeseries 与 Array 格式)
if isa(out_P1.theta_error, 'timeseries')
    err_phase1 = out_P1.theta_error.Data;
    err_phase2 = out_P2.theta_error.Data;
else
    err_phase1 = out_P1.theta_error;
    err_phase2 = out_P2.theta_error;
end
error_total = [err_phase1; err_phase2];

% 4. 召唤专业级图表 (双栏布局)
% 增大图表窗口的高度以容纳两张图
figure('Name', '数字孪生全局视图', 'Color', 'w', 'Position', [100, 100, 900, 700]);

% --- 上半部分：宏观角度 Theta ---
subplot(2, 1, 1);
plot(t_total, theta_total, 'b-', 'LineWidth', 1.5);
hold on;
xline(3.0, 'r--', '孪生参数下发点 (3s)', 'LineWidth', 2, 'LabelVerticalAlignment', 'bottom');
grid on;
ylabel('Theta (degrees)', 'FontWeight', 'bold');
title('物理系统全生命周期角度波形 (0~2s)', 'FontSize', 14);
set(gca, 'FontSize', 12);

% --- 下半部分：微观误差 Theta_error ---
subplot(2, 1, 2);
% 使用暗橘色或紫红色画误差，视觉对比更明显
plot(t_total, error_total, 'Color', [0.8500 0.3250 0.0980], 'LineWidth', 1.2); 
hold on;
xline(3.0, 'r--', '孪生参数下发点 (3s)', 'LineWidth', 2, 'LabelVerticalAlignment', 'bottom');
grid on;
xlabel('Time (s)', 'FontWeight', 'bold');
ylabel('Tracking Error', 'FontWeight', 'bold');
title('物理电机模型的角度输出跟踪角度输入的误差波形 (Theta Error)', 'FontSize', 14);
set(gca, 'FontSize', 12);

disp('🎨 图表绘制完成！请观察 3s 红线处的误差收敛情况。');






















