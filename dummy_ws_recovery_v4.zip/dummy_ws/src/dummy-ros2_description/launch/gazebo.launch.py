import os
import xacro
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, TimerAction
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare

def generate_launch_description():
    share_dir = get_package_share_directory('dummy-ros2_description')
    xacro_file = os.path.join(share_dir, 'urdf', 'dummy-ros2.xacro')
    robot_description_config = xacro.process_file(xacro_file)
    robot_urdf = robot_description_config.toxml()

    robot_state_publisher_node = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        parameters=[{'robot_description': robot_urdf, 'use_sim_time': True}]
    )

    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([PathJoinSubstitution([FindPackageShare('gazebo_ros'), 'launch', 'gazebo.launch.py'])]),
    )

    spawn_entity = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        arguments=['-entity', 'dummy-ros2', '-topic', 'robot_description']
    )
    delayed_spawn = TimerAction(period=5.0, actions=[spawn_entity])

    # ========================================================
    # 🌟 修复物理穿模：严格控制出生顺序，防止方块掉进桌子里
    # ========================================================

    # 1. 第 5 秒：先生成桌子 (X: 0.40, 刚好在机械臂前方)
    table_urdf_path = os.path.join(share_dir, 'urdf', 'table.urdf')
    spawn_table = Node(
        package='gazebo_ros', executable='spawn_entity.py',
        arguments=['-entity', 'simple_table', '-file', table_urdf_path, '-x', '0.40', '-y', '0.0', '-z', '0.0']
    )
    delayed_spawn_table = TimerAction(period=5.0, actions=[spawn_table])

    # 2. 第 8 秒：等桌子彻底变硬后，再在桌面上方生成方块
    # 桌子高 0.2m，方块出生在 0.22m，刚好落在桌面上
    box_urdf_path = os.path.join(share_dir, 'urdf', 'target_box.urdf')
    spawn_box = Node(
        package='gazebo_ros', executable='spawn_entity.py',
        arguments=['-entity', 'target_box', '-file', box_urdf_path, '-x', '0.40', '-y', '0.0', '-z', '0.22']
    )
    delayed_spawn_box = TimerAction(period=8.0, actions=[spawn_box])

    # MATLAB一致的红色球形障碍物
    # MATLAB/base_link: [0.15, -0.05, 0.15] m, r=0.03 m
    # base_link 相对 world 为 rpy=(pi,pi,0)，因此 Gazebo world 坐标为 [-0.15, 0.05, 0.15]
    obstacle_sdf_path = os.path.join(share_dir, 'models', 'obstacle_box', 'model.sdf')
    spawn_obstacle = Node(
        package='gazebo_ros', executable='spawn_entity.py',
        arguments=['-entity', 'obstacle_box', '-file', obstacle_sdf_path,
                   '-x', '-0.15', '-y', '0.05', '-z', '0.15']
    )
    delayed_spawn_obstacle = TimerAction(period=6.5, actions=[spawn_obstacle])

    # 3. 延后加载控制器，确保模型完全加载
    load_joint_state_broadcaster = Node(package="controller_manager", executable="spawner", arguments=["joint_state_broadcaster"])
    load_arm_controller = Node(package="controller_manager", executable="spawner", arguments=["arm_controller"])
    load_gripper_controller = Node(package="controller_manager", executable="spawner", arguments=["gripper_controller"])

    return LaunchDescription([
        robot_state_publisher_node, gazebo,
        delayed_spawn, 
        delayed_spawn_table, # 5秒出桌子
        delayed_spawn_obstacle, # 6.5秒出红色球
        delayed_spawn_box,   # 8秒出方块
        TimerAction(period=10.0, actions=[load_joint_state_broadcaster]),
        TimerAction(period=11.0, actions=[load_arm_controller]),
        TimerAction(period=11.5, actions=[load_gripper_controller]),
    ])
