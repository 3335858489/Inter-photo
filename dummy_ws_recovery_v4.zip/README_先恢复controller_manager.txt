恢复版 v4：先恢复 controller_manager，再继续处理非零 effort

本版严格基于你上传的 dummy_ws.zip 原工程生成。

【需要覆盖的文件】
1. ~/dummy_ws/src/dummy-ros2_description/urdf/dummy-ros2.xacro
2. ~/dummy_ws/src/dummy-ros2_description/launch/gazebo.launch.py
3. ~/dummy_ws/src/dummy-ros2_description/CMakeLists.txt
4. ~/dummy_ws/src/dummy-ros2_description/models/obstacle_box/model.sdf
5. ~/dummy_ws/src/dummy-ros2_description/models/obstacle_box/model.config

【不要替换】
- package.xml
- dummy-ros2.gazebo
- dummy-ros2.trans
- materials.xacro
- ros2_controllers.yaml
- moveit_controllers.yaml
- set_obstacle.py
- collision_replanner.py

【本版与 v3 的关键区别】
- 删除了 v3 加入的 position PID 参数。
- 删除了自动启动 disturbance bridge 的改动。
- 不再改 package.xml。
- 保留原工程的 controller 启动方式。
- 仅保留 effort state interface。
- 在原有 models/obstacle_box 文件夹内把障碍物改为红色球。
- gazebo.launch.py 只新增红色球 spawn，不重构原启动流程。

【MATLAB 障碍物一致性】
MATLAB/base_link 球心: [0.15, -0.05, 0.15] m
半径: 0.03 m
Gazebo world spawn: [-0.15, 0.05, 0.15] m
（由当前 base_link 的 rpy=(pi,pi,0) 坐标变换得到）

【替换后运行】
cd ~/dummy_ws
rm -rf build/dummy-ros2_description install/dummy-ros2_description
colcon build --symlink-install --packages-select dummy-ros2_description
source /opt/ros/humble/setup.bash
source ~/dummy_ws/install/setup.bash
export ROS_DOMAIN_ID=0
ros2 launch dummy-ros2_description gazebo.launch.py

等待约 15 秒后，新终端执行：
source /opt/ros/humble/setup.bash
source ~/dummy_ws/install/setup.bash
export ROS_DOMAIN_ID=0
ros2 node list | grep controller_manager
ros2 control list_controllers
ros2 control list_hardware_interfaces

成功标志：
/controller_manager 存在，三个 controller 可列出。

注意：
这一版优先恢复原本正常工作的 controller_manager。
effort 可能仍然是 0；不要在 controller_manager 恢复前继续改 PID。
